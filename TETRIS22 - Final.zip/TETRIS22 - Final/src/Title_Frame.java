/*
Rowan Casselman
01 - 21 - 2020
Title frame for user to be pleased by music and gif then start the game, or quit.
 */
import javax.swing.ImageIcon;

public class Title_Frame extends javax.swing.JFrame {
    Game game;
    /**
     * Creates new form Title_Frame
     */
    public Title_Frame() {
        initComponents();
    }
    int highScore;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBackgroundOne = new javax.swing.JPanel();
        panelBackgroundTwo = new javax.swing.JPanel();
        btnPlay = new javax.swing.JButton();
        btnQuit = new javax.swing.JButton();
        lblTetris = new javax.swing.JLabel();
        lblPicture = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(new java.awt.Color(0, 0, 0));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        panelBackgroundOne.setBackground(new java.awt.Color(255, 255, 255));
        panelBackgroundOne.setPreferredSize(new java.awt.Dimension(780, 533));

        panelBackgroundTwo.setBackground(new java.awt.Color(102, 102, 102));

        btnPlay.setText("Play");
        btnPlay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlayActionPerformed(evt);
            }
        });

        btnQuit.setText("Quit");
        btnQuit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuitActionPerformed(evt);
            }
        });

        lblTetris.setFont(new java.awt.Font("Lithos Pro", 1, 64)); // NOI18N
        lblTetris.setForeground(new java.awt.Color(255, 255, 255));
        lblTetris.setText("TETRIS");

        javax.swing.GroupLayout panelBackgroundTwoLayout = new javax.swing.GroupLayout(panelBackgroundTwo);
        panelBackgroundTwo.setLayout(panelBackgroundTwoLayout);
        panelBackgroundTwoLayout.setHorizontalGroup(
            panelBackgroundTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBackgroundTwoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelBackgroundTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBackgroundTwoLayout.createSequentialGroup()
                        .addComponent(btnPlay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBackgroundTwoLayout.createSequentialGroup()
                        .addGap(0, 24, Short.MAX_VALUE)
                        .addComponent(lblTetris)
                        .addGap(25, 25, 25))
                    .addGroup(panelBackgroundTwoLayout.createSequentialGroup()
                        .addComponent(btnQuit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        panelBackgroundTwoLayout.setVerticalGroup(
            panelBackgroundTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBackgroundTwoLayout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addComponent(lblTetris)
                .addGap(51, 51, 51)
                .addComponent(btnPlay, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnQuit, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelBackgroundOneLayout = new javax.swing.GroupLayout(panelBackgroundOne);
        panelBackgroundOne.setLayout(panelBackgroundOneLayout);
        panelBackgroundOneLayout.setHorizontalGroup(
            panelBackgroundOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBackgroundOneLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(lblPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(panelBackgroundTwo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );
        panelBackgroundOneLayout.setVerticalGroup(
            panelBackgroundOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBackgroundTwo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBackgroundOneLayout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addComponent(lblPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBackgroundOne, javax.swing.GroupLayout.DEFAULT_SIZE, 820, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBackgroundOne, javax.swing.GroupLayout.PREFERRED_SIZE, 762, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnPlayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlayActionPerformed
        Game game = new Game(); //Starts the game
        game.run(); //Runs it so it opens
        this.setVisible(false); //Makes this panel go away
    }//GEN-LAST:event_btnPlayActionPerformed
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        Music musicObject = new Music(); //creates new class called music
        String filepath = "tetris.wav"; //finds filepath of song wanted to play
        musicObject.playMusic(filepath); //plays the song
      
        lblPicture.setIcon(new ImageIcon("tetris.gif")); //puts a gif on title page
    }//GEN-LAST:event_formWindowOpened

    private void btnQuitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuitActionPerformed
        System.exit(0); //quits everything
    }//GEN-LAST:event_btnQuitActionPerformed
   

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Title_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Title_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Title_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Title_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Title_Frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPlay;
    private javax.swing.JButton btnQuit;
    private javax.swing.JLabel lblPicture;
    private javax.swing.JLabel lblTetris;
    private javax.swing.JPanel panelBackgroundOne;
    private javax.swing.JPanel panelBackgroundTwo;
    // End of variables declaration//GEN-END:variables
}
