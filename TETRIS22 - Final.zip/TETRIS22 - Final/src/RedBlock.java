/*
 * Gwyneth Armstrong
 * January 9, 2020
 * Subclass of Block, specific to red blocks.
 */

/**
 *
 * @author Gwyneth
 */
import java.awt.*;
public class RedBlock extends Block {
    //Variables
    boolean[][][] shape = {
                            { //first rotation
                                {false, false, true},
                                {false, true, true},
                                {false, true, false}
                            },
                            { //second rotation
                                {false, false, false},
                                {true, true, false},
                                {false, true, true}
                            },
                            { //third rotation
                                {false, true, false},
                                {true, true, false},
                                {true, false, false}
                            },
                            { //fourth rotation
                                {true, true, false},
                                {false, true, true},
                                {false, false, false}
                            }
                          };
    static Color color = Color.RED;
    
    //Constrcutors
    public RedBlock (int xPos, int yPos){
        super(xPos, yPos);
        super.setShape(shape);
        super.setColor(color);
    }
}
