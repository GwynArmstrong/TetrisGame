/*
Edwin Mooney
2019 - 12 - 27 
Test program for me to learn how to use the graphics class in JAVA

Rowan Casselman
01 - 21 - 2020
Speed up time of game, link this to end frame(stats/opening)
 */

//Graphics Imports:
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.*;
import javax.swing.*;
import java.util.Timer;
//Other Imports:
import java.util.Arrays;

public class Game extends JPanel {
    JFrame frame;
    //Variables:
    Color[][] mainArray;        //main array that represents the game play screen
    static int size = 30;       //sets the size for each square on the grid
    Block fallingBlock;         //falling block that is moved and rotated
    Block queueBlock;           //block that is queued to fall
    Block heldBlock;            //block that is held
    boolean start = false;
    boolean running = true;
    int score = 0;              //score starts at 0
    int lines = 0;              //lines made start at 0
    int highScore = 0;
    //Constructor builds a new JFrame sets all the components and properties
    public Game() {

        frame = new JFrame("Main Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(this);
        frame.setSize(size * 18 - 5, size * 26 + 10);
        frame.setLocationRelativeTo(null);    //centers the frame
        frame.setVisible(true);
        initializeArray(); //create and initiate the game screen
        addKeyListener(frame);  //add the key listener for key input

    }

    //arrow key and space bar controls
    public void addKeyListener(JFrame f) {
        f.addKeyListener(new KeyListener() {    //create a new listening object that is always listening for input
            public void keyTyped(KeyEvent e) {

            }

            public void keyPressed(KeyEvent e) {

                switch (e.getKeyCode()) {

                    case KeyEvent.VK_UP:
                        fallingBlock.rotate(mainArray);  //tries to rotate
                        updateGraphics();   //update the graphics once the move is complete
                        break;

                    case KeyEvent.VK_LEFT:
                        fallingBlock.moveLeft(mainArray);   //move the block left
                        updateGraphics();
                        break;

                    case KeyEvent.VK_RIGHT:
                        fallingBlock.moveRight(mainArray);   //move the block left
                        updateGraphics();
                        break;

                    case KeyEvent.VK_DOWN:
                        if (fallingBlock.checkCollision(mainArray, "down")) {   //if it can fall
                            fallingBlock.fall(mainArray);
                        } else {
                            addToWell();  //if the block cannot go down any farther, it has reached the bottom and a new block is added
                        }
                        updateGraphics();
                        break;

                    case KeyEvent.VK_SPACE:
                        while (fallingBlock.checkCollision(mainArray, "down")) {
                            fallingBlock.fall(mainArray);
                        }
                        updateGraphics();   //update the graphics after the block is moved all the way down, because it is supposed to shoot down instantely
                        addToWell();  //because I don't want to show each transition downwards
                        break;
                    
                    case KeyEvent.VK_C:
                        holdBlock();
                        break;
                }

            }

            public void keyReleased(KeyEvent e) {
            }
        });
    }

    public void initializeArray() {
        mainArray = new Color[17][26];  //game dimension is 10 x 20: 
        //extra 4 in the y direction so the blocks can generate off screen and fall onto the screen
        //extra 5 in the x direction for the queue block display and scores

        for (int x = 0; x < mainArray.length; x++) {   //while x is less than the width of the frame
            for (int y = 0; y < mainArray[x].length; y++) {     //while y is less than the height
                mainArray[x][y] = Color.WHITE;      //sets the entire array to white so it can be drawn over
            }
        }
        setBorders();       //set the borders in the array
    }

    public void run() {
        //this is where the bulk of the program runs
        setBorders();
        queueBlock = generateNewBlock();
        
        new Thread() {          //creates a new thread for this loop to run so that it does not affect the main thread and other controls
            public void run() {
                int fallTime = 1000;
                addFallingBlock();      //add the first falling block
                while (running == true) { 
                    while (fallingBlock.checkCollision(mainArray, "down")) {      //while there is nothing in the way
                        fallingBlock.fall(mainArray);        //move the block down by one
                        updateGraphics();          //update the graphics by painting the defined area 
                        try {
                            Thread.sleep(fallTime);     //tells the thread to sleep for a set amount of milliseconds                   
                        } catch (InterruptedException e) {
                        }      //error for thread.sleep()
       
                            fallTime = (int)(fallTime - 1); 
                    }
                    addToWell();  //adds the old block to the the well and generates a new block
                    
                }
                
            }
        }.start();  //start the thread

    }
    
    public void updateGraphics() {
        this.paintImmediately(0, 0, 2000, 2000);    //update the graphics by painting the defined area 
    }
    
    public void paint(Graphics g) {
        super.paint(g); //clears the current screen so it doesn't do the windows xp thing

        //run through each part of the array to create a grid of colors on the screen
        for (int x = 0; x < mainArray.length; x++) {   //while x is less than the width of the frame
            for (int y = 2; y < mainArray[x].length; y++) {     //while y is less than the height   //start at 3 so the top 4 squares aren't drawn

                //fill rectange with the correspoding color from the array
                g.setColor(mainArray[x][y]);
                g.fillRect(x * size, (y - 2) * size, size, size);

                //draw grid on top
                    //first grid in game frame      //second grid for hold frame
                if((x > 0 && x < 11 && y < 25) || (x > 11 && x < 16 && y > 2 && y < 7) || (x > 11 && x < 16 && y > 7 && y < 12)){
                    g.setColor(Color.GRAY);
                    g.drawRect(x * size, (y - 2) * size, size, size);
                }
            }
        }
        //Title for the next block
        g.setColor(Color.WHITE);
        g.drawString("Next:", size * 13, 20);
        //Title for the hold block
        g.drawString("Hold:", size * 13, size * 6 - 10);
        
        //Score Display
        g.drawString("Score: " + score, size * 13, size * 11);
    }
    
    public void setBorders() {
        //set the borders of the well
        //set the verticle borders
        for (int y = 0; y < mainArray[0].length; y++) {
            mainArray[0][y] = Color.BLACK;  //moved over 1 so that the light blue block doesnt run into out of bounds errors when it tries to rotate
            mainArray[11][y] = Color.BLACK;
            mainArray[16][y] = Color.BLACK;
        }
        //set the horizontal bottom border
        for (int x = 0; x < mainArray.length; x++) {
            mainArray[x][25] = Color.BLACK;
        }
        
        for(int x = 11; x < mainArray.length; x++){
            mainArray[x][2] = Color.BLACK;
            mainArray[x][7] = Color.BLACK;
            mainArray[x][12] = Color.BLACK;
        }
        
        //set the borders at the bottom of the right side
        for(int x = 11; x < mainArray.length; x++){
            for(int y = 12; y < mainArray[x].length; y++){
                mainArray[x][y] = Color.BLACK;
            }
        }
    }
    
    public void addToWell() {
        lineClear();
        checkIfEnd();
        addFallingBlock();
    }

    public void lineClear() {
        boolean gap;    //starts false, and if there is gap found, it is set to true
        int rowsCleared = 0;
        for (int y = mainArray[1].length - 2; y > 0; y--) {  //starts at the bottom row and moves up (start at 24 to ignore the bottom border)
            gap = false;
            for (int x = 0; x < 11; x++) {  //checks each column in that row for a white space
                if (mainArray[x][y] == Color.WHITE) { //if there is any white in the line there is a gap
                    gap = true;
                }
            }
            if (!gap) {   //if there is no gap
                deleteRow(y);
                y++;
                rowsCleared++;
            }
        }
        switch(rowsCleared){
            case 1:
                score += 100;
                lines++;
                break;
                
            case 2:
                score += 400;
                lines = lines + 2;
                break;
                
            case 3:
                score += 900;
                lines = lines + 3;
                break;
                //TETRIS!!!
            case 4:
                score += 1600;
                lines = lines + 4;
        }
    }
    
    public void deleteRow(int row) {
        //runs all the way up through the main array, copying the row above to the row below
        for (int y = row - 1; y >= 0; y--){
            for(int x = 0; x < 11; x++){
                mainArray[x][y + 1] = mainArray[x][y];
            }
        }
    }
    
    public void getHighScore(int score) {
        if(score > highScore) {
            highScore = score; //method if new score is bigger than highscore it sets it to new one
        }
    }
    
    public void setHighScore(int high) {
        highScore = high; //This method is for the end frame, so when making new games
                          // its able to keep the high score
    }
    
    public void checkIfEnd(){
        for(int x = 1; x < 11; x++){    //(start at 1 to ignore the border)
            if (mainArray[x][2] != Color.WHITE){
                End_Frame endframe = new End_Frame(); //Creates new endframe after losing
                getHighScore(score); //sees if new score is higher then high score and sets it to it if so
                endframe.getStats(score, lines, highScore); // uses method in endframe
                endframe.showStats(); //uses method in endframe 
                running = false; //it stops running
                System.out.println("Game Over"); //prints game over
                frame.setVisible(false); //closes this window
                endframe.setVisible(true); //opens new end frame
                break; //finally breaks the loop
            }
        }
    }
    public void addFallingBlock() {
        queueBlock.removeFromArray(mainArray);
        fallingBlock = queueBlock;           //pulls the randomly generated block from the queue
        fallingBlock.setXPos(5);
        fallingBlock.setYPos(0);
        mainArray = fallingBlock.addToArray(mainArray); //adds the falling block to the array
        queueBlock = generateNewBlock();
        queueBlock.addToArray(mainArray);
    }

    public Block generateNewBlock() {
        //Edwin & Gwyneth - 2020/01/14 - generates a new random block and stores it in the variable name "queueBlock"

        int colorUsed = (int)(Math.random() * 7) + 1;    //generates a random number to tell us which colour of block to use and stores as a double
        //1 = red block
        //2 = orange block
        //3 = yellow block
        //4 = green block
        //5 = light blue block
        //6 = blue block
        //7 = purple block
        int offset = 0;
        switch (colorUsed){
            case 1:
                queueBlock = new RedBlock(12, 3);
                break;

            case 2:
                queueBlock = new OrangeBlock(12, 3);
                break;

            case 3:
                queueBlock = new YellowBlock(12, 3);
                break;

            case 4:
                queueBlock = new GreenBlock(12, 3);
                break;

            case 5:
                queueBlock = new LightBlueBlock(12, 3);
                break;

            case 6:
                queueBlock = new BlueBlock(12, 3);
                break;

            case 7:
                queueBlock = new PurpleBlock(12, 3);
                break;

            default:
                System.out.println("ERROR: generateQueueBlock: random number isnt in range of 1 -7");
        }
        return queueBlock;
    }
    
    public void holdBlock(){
        //remove the blocks from the array
        fallingBlock.removeFromArray(mainArray);
        //if there is no held block, just create a new falling block instead of switching them
        if(heldBlock == null){
            System.out.println("Hey");
            heldBlock = fallingBlock;   //store the falling block for later
            addFallingBlock();  //add a new falling block
        }
        //otherwise just switch them
        else{
            heldBlock.removeFromArray(mainArray);
            Block temp = fallingBlock;
            fallingBlock = heldBlock;
            heldBlock = temp;
            fallingBlock.setXPos(4);
            fallingBlock.setYPos(0);
            //add them back to the array
            fallingBlock.addToArray(mainArray);

        }
        
        //set their new positions
        heldBlock.setXPos(12);
        heldBlock.setYPos(8);

        //add them back to the array

        heldBlock.addToArray(mainArray);

    }
}
