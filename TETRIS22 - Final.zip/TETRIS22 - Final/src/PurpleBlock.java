/*
Edwin Mooney
2019 - 12 - 30
Specific class to represent a specific block. Extends Block class
 */
import java.awt.*;
public class PurpleBlock extends Block{
    //Variables
    boolean[][][] shape = {
                            { //first rotation
                                {false, true, false},
                                {true, true, true},
                                {false, false, false}
                            },
                            { //second rotation
                                {false, true, false},
                                {false, true, true},
                                {false, true, false}
                            },
                            { //third rotation
                                {false, false, false},
                                {true, true, true},
                                {false, true, false}
                            },
                            { //fourth rotation
                                {false, true, false},
                                {true, true, false},
                                {false, true, false}
                            }
                          };
    static Color color = Color.MAGENTA;
    
    //Constructor:
    public PurpleBlock (int xPos, int yPos){
        super(xPos, yPos);
        super.setColor(color);
        super.setShape(shape);
    }
    
}

