/*
 * Gwyneth Armstrong
 * January 8, 2020
 * Subclass of block specific to light blue blocks.
 */

/**
 *
 * @author Gwyneth
 */
import java.awt.*;
public class LightBlueBlock extends Block {
    //Variables
    boolean[][][] shape = {   
                            { //first rotation
                                {false, false, true, false},
                                {false, false, true, false},
                                {false, false, true, false},
                                {false, false, true, false}
                            },
                            { //second rotation
                                {false, false, false, false},
                                {false, false, false, false},
                                {true, true, true, true},
                                {false, false, false, false}
                            },
                            { //third rotation
                                {false, true, false, false},
                                {false, true, false, false},
                                {false, true, false, false},
                                {false, true, false, false}
                            },
                            { //fourth rotation
                                {false, false, false, false},
                                {true, true, true, true},
                                {false, false, false, false},
                                {false, false, false, false} 
                            }
                        };
    static Color color = Color.CYAN;
    
    //Constructor
    public LightBlueBlock(int xPos, int yPos){
        super(xPos, yPos);
        super.setColor(color);
        super.setShape(shape);
    }
}
