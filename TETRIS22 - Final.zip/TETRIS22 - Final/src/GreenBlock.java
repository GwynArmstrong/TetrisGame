/*
Edwin Mooney
2019 - 12 - 30
Specific class to represent a specific block. Extends Block class
 */
import java.awt.*;
public class GreenBlock extends Block{
    //Variables
    boolean[][][] shape = {
                            { //first rotation
                                {false, true, false},
                                {false, true, true},
                                {false, false, true}
                            },
                            { //second rotation
                                {false, false, false},
                                {false, true, true},
                                {true, true, false}
                            },
                            { //third rotation
                                {true, false, false},
                                {true, true, false},
                                {false, true, false}
                            },
                            { //fourth rotation
                                {false, true, true},
                                {true, true, false},
                                {false, false, false}
                            }
                          };
    static Color color = Color.GREEN;
    
    //Constructor:
    public GreenBlock (int xPos, int yPos){
        super(xPos, yPos);
        super.setColor(color);
        super.setShape(shape);
    }
    
}
