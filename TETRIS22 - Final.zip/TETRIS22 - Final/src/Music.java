/*
Rowan Casselman
01 - 21 - 2020
Class to make music be able to play, opening it to stream
 */
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.Clip;
import javax.swing.JOptionPane;

public class Music { 

    public void playMusic(String musicLocation) {
        try {
            //try getting the music that is inputed when calling and make it able to stream
            File musicPath = new File(musicLocation);        
            AudioInputStream audioInput = AudioSystem.getAudioInputStream(musicPath);
            Clip clip = AudioSystem.getClip(); //creates a clip for it
            
            clip.open(audioInput); //opens clip so it is able to use
            clip.start(); //starts song
            clip.loop(Clip.LOOP_CONTINUOUSLY); //loops it continuously
                 
        } catch(Exception e) {
        }
    }
    
    
}