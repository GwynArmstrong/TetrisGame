/*
Edwin Mooney
2019 - 12 - 30
Specific class to represent a specific block. Extends Block class
 */
import java.awt.*;
public class BlueBlock extends Block{
    //Variables
    boolean[][][] shape = {
                            { //first rotation
                                {true, false, false},
                                {true, true, true},
                                {false, false, false}
                            },
                            { //second rotation
                                {false, true, true},
                                {false, true, false},
                                {false, true, false}
                            },
                            { //third rotation
                                {false, false, false},
                                {true, true, true},
                                {false, false, true}
                            },
                            { //fourth rotation
                                {false, true, false},
                                {false, true, false},
                                {true, true, false}
                            }
                          };
    static Color color = Color.BLUE;
    
    //Constructor:
    public BlueBlock (int xPos, int yPos){
        super(xPos, yPos);
        super.setColor(color);
        super.setShape(shape);
    }
    
}

