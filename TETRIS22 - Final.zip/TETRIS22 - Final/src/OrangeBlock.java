/*
Edwin Mooney
2019 - 12 - 30
Specific class to represent a specific block. Extends Block class
 */
import java.awt.*;
public class OrangeBlock extends Block{
    //Variables
    boolean[][][] shape = {
                            { //first rotation
                                {false, false, true},
                                {true, true, true},
                                {false, false, false}
                            },
                            { //second rotation
                                {false, true, false},
                                {false, true, false},
                                {false, true, true}
                            },
                            { //third rotation
                                {false, false, false},
                                {true, true, true},
                                {true, false, false}
                            },
                            { //fourth rotation
                                {true, true, false},
                                {false, true, false},
                                {false, true, false}
                            }
                          };
    static Color color = Color.ORANGE;
    
    //Constructor:
    public OrangeBlock (int xPos, int yPos){
        super(xPos, yPos);
        super.setColor(color);
        super.setShape(shape);
    }
    
}
