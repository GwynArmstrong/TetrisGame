/*
Edwin Mooney
2019 - 12 - 30
Block class for all the blocks in TETRIS. 
 */
import java.awt.*;

abstract public class Block {

    int xPos;
    int yPos;
    int rotation;
    boolean shape[][][];
    Color color;
    //Constructor:

    public Block(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }
    //Setters and Getters:

    public void setXPos(int xPos) {
        this.xPos = xPos;
    }

    public int getXPos() {
        return this.xPos;
    }

    public void setYPos(int yPos) {
        this.yPos = yPos;
    }

    public int getYPos() {
        return this.yPos;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public boolean[][][] getShape() {
        return shape;
    }

    public void setShape(boolean[][][] shape) {
        this.shape = shape;
    }

    //method adds the shape of the object to any input array
    public Color[][] addToArray(Color[][] array) {

        //finally, add the block to the array ofset by the difference so that it each block can generate right above the game screen
        for (int y = 0; y < shape[rotation].length; y++) {
            for (int x = 0; x < shape[rotation][y].length; x++) {
                if (shape[rotation][y][x] == true) {
                    array[xPos + x][yPos + y] = this.color;
                }
            }
        }
        return array;
    }

    //removes the block from an input array
    public Color[][] removeFromArray(Color[][] array) {
        for (int y = 0; y < shape[rotation].length; y++) {
            for (int x = 0; x < shape[rotation][y].length; x++) {
                if (shape[rotation][y][x] == true) {
                    array[xPos + x][yPos + y] = Color.WHITE;
                }
            }
        }
        return array;
    }

    //fall method moves removes the block, moves it down one, then adds it back
    public Color[][] fall(Color[][] array) {
        //Edwin Mooney
        //2020 - 01 - 09
        array = this.removeFromArray(array);    //removes the block from the array
        if (checkCollision(array, "down")) {
            this.yPos++;                            //drops the block down by 1
        } else {
            //do nothing
        }
        array = this.addToArray(array);         //adds the moved block back to the array
        return array;
    }

    public boolean checkCollision(Color[][] array, String direction) {
        //2020 - 01 - 13
        //Edwin Mooney
        //checks the next block to see if the falling block should collide with it

        boolean canMove = true;

        switch (direction) {
            case "left":
                for (int y = 0; y < shape[rotation].length; y++) {
                    for (int x = 0; x < shape[rotation][y].length; x++) {
                        if (shape[rotation][y][x] == true) {  //if there is a block section at this point
                            if (array[xPos + x - 1][yPos + y] != Color.WHITE) {   //"-1" because it's cheking to the left
                                canMove = false;
                            }

                            x = 5;  //the search through the array starts at the left and only the left most blokc in this row matters
                            //therefore the loop can be closed and the search can move onto the next row
                        }
                    }
                }
                break;

            case "right":
                for (int y = 0; y < shape[rotation].length; y++) {
                    for (int x = shape[rotation][y].length - 1; x >= 0; x--) {
                        if (shape[rotation][y][x] == true) {  //if there is a block section at this point
                            if (array[xPos + x + 1][yPos + y] != Color.WHITE) {   //"+1" because it's cheking to the right
                                canMove = false;
                            }

                            x = -1;  //the search through the array starts at the right and only the right most block in this row matters
                            //therefore the loop can be closed and the search can move onto the next row
                        }
                    }
                }
                break;

            case "down":
                for (int x = 0; x < shape[rotation].length; x++) {
                    for (int y = shape[rotation][x].length - 1; y >= 0; y--) {    //starting from the bottom of each column and searching upwards
                        if (shape[rotation][y][x] == true) {
                            if (array[xPos + x][yPos + y + 1] != Color.WHITE) {
                                canMove = false;
                            }

                            y = -1;    //the search starts at the bottom, and only the most bottom blocks matter
                            //so the search can stop and move onto the next column
                        }
                    }
                }
                break;
            case "rotate":
                int compareRotation;    //comparative rotation used to compare the next rotation
                if (rotation >= shape.length - 1) {
                    compareRotation = -1;  //if the rotation variable is at the last index, set the comarative rotation to -1 so it can be used to compare to index 0;
                } else {
                    compareRotation = rotation; //if not, set the comparative rotation to the current rotation
                }
                //check the location of the next rotation and see if it can rotate
                for (int x = 0; x < shape[compareRotation + 1].length; x++) {   //check the next rotation to see if there is something in the way
                    for (int y = 0; y < shape[compareRotation + 1][x].length; y++) {
                         if (array[xPos + x][yPos + y] != Color.WHITE) {    //if there is a block in the way
                            canMove = false;
                        }
                        
                    }
                }
                break;  
        }

        return canMove;
    }

    //Gwyneth Armstrong - January 6, 2020
    //method to move the block to the right one space
    public void moveRight(Color[][] array) {
        array = this.removeFromArray(array);
        if (checkCollision(array, "right")) {
            this.xPos++;
        }
        array = this.addToArray(array);
    }

    //method to move the block to the left one space
    public void moveLeft(Color[][] array) {
        array = this.removeFromArray(array);
        if (checkCollision(array, "left")) {
            this.xPos--;
        }
        array = this.addToArray(array);
    }

    public void rotate(Color[][] array) {
        //Edwin Mooney - 2020/01/14
        //moving each of the elements in the 4 by 4 array to their new spot after being rotated clockwise once
        //to do this, the program must move onto the next index of the Shape array section for rotation
        this.removeFromArray(array);
        
        if (checkCollision(array, "rotate")) {
            if (rotation >= shape.length - 1) {
                //if the rotation number is less than the length of the array at the rotation index
                rotation = 0;
            } else {
                rotation++;
            }
        }
        else{   //if there is something in the way
                //move it away from the collision
            if(checkCollision(array, "left")){  //checks if there is something to the left
                xPos--;                         //if nothing is there, then the object must be on the right, and move it
            }
            else{
                xPos++;     //oppostite of above
            }
            //then try and rotate again
            rotate(array);
        }
        
        this.addToArray(array);
    }

    public int findOffset() {
        /*Edwin Mooney - 2020/01/14
       This method uses this objects shape to determine the difference between the bottom of the shape array and the lowest most point.
       This difference is the offset need when initializing a new block above the game. 
       This is done so that each block generates only 1 space above the visible game screen
         */
        //first find the lowest most part of the block
        int temp;
        int lowestPoint = 0;
        for (int x = 0; x < shape.length; x++) {
            for (int y = 3; y >= 0; y--) {    //starting from the bottom of each column and searching upwards
                if (shape[rotation][y][x] == true) {    //if it finds a part of the block

                    temp = y;   //set the temporary number to equal the lowest point in that column
                    if (temp > lowestPoint) {    //if the newly found point is lower than the current lowest point
                        lowestPoint = temp;      //set the lowest point to the newly found point
                    }

                    y = -1;    //the search starts at the bottom, and only the most bottom blocks matter
                    //so the search can stop and move onto the next column
                }
            }
        }
        //then find the difference between the bottom of the shape array and the bottom block
        int offset = 4 - lowestPoint;   //find the difference by using the lowest point and subtracting it from the the size of the shape array(which is 4)
        return offset;
    }
}
