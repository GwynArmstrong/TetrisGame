/*
 * Gwyneth Armstrong
 * January 8, 2020
 * Subclass of Block, specific to yellow blocks.
 */

/**
 *
 * @author Gwyneth
 */
import java.awt.*;
public class YellowBlock extends Block {
    //Variables
    boolean[][][] shape ={ 
                            { //first and only rotation
                                {true, true, false},
                                {true, true, false},
                                {false, false, false}
                            } 
                         };
    static Color color = Color.YELLOW;
    
    //Constructor
    public YellowBlock(int xPos, int yPos){
        super(xPos, yPos);
        super.setColor(color);
        super.setShape(shape);
    }
    
}
